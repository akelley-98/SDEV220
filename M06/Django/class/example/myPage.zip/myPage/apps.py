from django.apps import AppConfig


class MypageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myPage'
